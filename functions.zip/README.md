
完成功能： 

​ 1，创建AWS账户，配置ARN，创建Bucket，创建dynamoDB table，开启 cloudwatch服务，配置SNS服务。

​ 2，创建lambda 函数，编写代码。

​ 3，使用函数控制面板的测试用例进行测试。


未完成功能：

​ 1，数据无法写入dynamoDB。

​ 2，未完成 CloudFormation的部署实践。

​ 3，未完成API Gateway 触发操作实践。

​ 4，未能实现发送消息到SNS中。
